' MEANCURE.vbs
' Launches the Streamlit app using the user's own Python 3 installation.
' All application files live in the "_internal" subfolder next to this script.
' No Python runtime or compiled wrapper exe is bundled � this avoids
' Windows Smart App Control flagging an unknown/unsigned binary.

Option Explicit

Dim fso, shell, scriptDir, appDir, launcherPath

On Error Resume Next
Set fso   = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
If Err.Number <> 0 Then
    MsgBox "MEANCURE failed to start: could not create required Windows " & _
           "scripting objects." & vbCrLf & vbCrLf & "Error: " & Err.Description, _
           vbCritical, "MEANCURE - Fatal Error"
    WScript.Quit 1
End If
On Error Goto 0

scriptDir    = fso.GetParentFolderName(WScript.ScriptFullName)
appDir       = scriptDir & "\_internal"
launcherPath = appDir & "\launcher.py"

If Not fso.FolderExists(appDir) Then
    MsgBox "The '_internal' folder was not found next to this script:" & vbCrLf & appDir, _
           vbCritical, "MEANCURE - Error"
    WScript.Quit 1
End If

If Not fso.FileExists(launcherPath) Then
    MsgBox "launcher.py was not found inside:" & vbCrLf & appDir, _
           vbCritical, "MEANCURE - Error"
    WScript.Quit 1
End If

Dim interpreter, useLauncherFlag
interpreter     = ""
useLauncherFlag = False

' Detect Python by scanning PATH directly via the filesystem � NOT by
' spawning "where.exe" as a child process. This is instant, cannot hang,
' and cannot be silently blocked by process-creation security policies.
If FindOnPath("pyw.exe") <> "" Then
    interpreter     = "pyw.exe"
    useLauncherFlag = True
ElseIf FindOnPath("py.exe") <> "" Then
    interpreter     = "py.exe"
    useLauncherFlag = True
ElseIf FindOnPath("pythonw.exe") <> "" Then
    interpreter = "pythonw.exe"
ElseIf FindOnPath("python.exe") <> "" Then
    interpreter = "python.exe"
End If

If interpreter = "" Then
    Dim msg
    msg = "Python was not found on this computer." & vbCrLf & vbCrLf & _
          "MEANCURE requires Python 3.9 or newer to run." & vbCrLf & vbCrLf & _
          "Please install it from the official site:" & vbCrLf & _
          "  https://www.python.org/downloads/" & vbCrLf & vbCrLf & _
          "IMPORTANT: during installation, check the box" & vbCrLf & _
          "  'Add python.exe to PATH'" & vbCrLf & _
          "otherwise Windows will not be able to find it afterwards." & vbCrLf & vbCrLf & _
          "After installing, restart your computer (or at least log out " & _
          "and back in) so the PATH change takes effect, then run " & _
          "MEANCURE.vbs again." & vbCrLf & vbCrLf & _
          "Open the download page now?"
    If MsgBox(msg, vbYesNo + vbExclamation, "MEANCURE - Python not found") = vbYes Then
        On Error Resume Next
        shell.Run "https://www.python.org/downloads/", 1, False
        On Error Goto 0
    End If
    WScript.Quit 1
End If

Dim cmd
If useLauncherFlag Then
    cmd = interpreter & " -3 """ & launcherPath & """"
Else
    cmd = """" & interpreter & """ """ & launcherPath & """"
End If

On Error Resume Next
shell.CurrentDirectory = appDir
shell.Run cmd, 0, False
If Err.Number <> 0 Then
    MsgBox "MEANCURE found Python, but failed to launch it." & vbCrLf & vbCrLf & _
           "Command: " & cmd & vbCrLf & vbCrLf & _
           "Error: " & Err.Description, _
           vbCritical, "MEANCURE - Launch failed"
    WScript.Quit 1
End If
On Error Goto 0

' ---------------------------------------------------------------------------
' Scans each directory in %PATH% for exeName using plain filesystem checks �
' no subprocess is spawned, so this cannot hang or get silently blocked.
Function FindOnPath(exeName)
    Dim pathEnv, dirs, i, dirPath, candidate
    FindOnPath = ""

    On Error Resume Next
    pathEnv = shell.ExpandEnvironmentStrings("%PATH%")
    On Error Goto 0

    If pathEnv = "" Or pathEnv = "%PATH%" Then Exit Function

    dirs = Split(pathEnv, ";")
    For i = 0 To UBound(dirs)
        dirPath = Trim(dirs(i))
        If dirPath <> "" Then
            On Error Resume Next
            candidate = fso.BuildPath(dirPath, exeName)
            If fso.FileExists(candidate) Then
                FindOnPath = candidate
                Exit Function
            End If
            On Error Goto 0
        End If
    Next
End Function