#!/usr/bin/env python3
"""
MEANCURE launcher for Linux / macOS.

Usage:
    python3 meancure.py
    ./meancure.py          (after: chmod +x meancure.py)

Uses whatever Python 3.9+ interpreter you already have installed — no
bundled runtime is shipped. BLAST+ (blastn, makeblastdb) must also be
installed separately and available on PATH; if it's missing, this script
prints clear installation instructions and the app's own "Dependencies"
page will keep reminding you until it's resolved.

All application files (app.py, pages/, etc.) live in the "_internal"
subfolder next to this script.
"""
from __future__ import annotations

import os
import platform
import sys
import threading
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
APP_DIR = SCRIPT_DIR / "_internal"
sys.path.insert(0, str(APP_DIR))

REQUIREMENTS_FILE = APP_DIR / "requirements.txt"
MIN_PYTHON = (3, 9)


def _print_box(title: str, lines: list[str]) -> None:
    width = max([len(title)] + [len(l) for l in lines] + [40]) + 4
    print("\n┌" + "─" * width + "┐")
    print("│ " + title.ljust(width - 1) + "│")
    print("├" + "─" * width + "┤")
    for line in lines:
        print("│ " + line.ljust(width - 1) + "│")
    print("└" + "─" * width + "┘\n")


def _check_app_dir() -> None:
    if not APP_DIR.is_dir() or not (APP_DIR / "app.py").exists():
        _print_box(
            "MEANCURE - Error",
            [
                "The '_internal' folder (containing app.py) was not found",
                f"next to this script. Expected: {APP_DIR}",
            ],
        )
        sys.exit(1)


def _check_python_version() -> None:
    if sys.version_info < MIN_PYTHON:
        _print_box(
            "MEANCURE - Unsupported Python version",
            [
                f"MEANCURE requires Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer.",
                f"Found: {sys.version.split()[0]} ({sys.executable})",
                "",
                "Install a newer Python via your package manager, e.g.:",
                "  sudo apt-get install python3.11 python3.11-venv   # Debian/Ubuntu",
                "  sudo dnf install python3.11                        # Fedora",
                "  sudo pacman -S python                              # Arch",
                "or download from https://www.python.org/downloads/",
            ],
        )
        sys.exit(1)


def _ensure_packages_installed() -> None:
    """
    Reuses dependency_manager.py's own logic so the launcher and the
    in-app Dependencies page never drift out of sync with each other.
    """
    try:
        import streamlit  # noqa: F401
        return
    except ImportError:
        pass

    import dependency_manager as dm

    print("First-time setup: installing required Python packages (this can take a minute)...")

    missing = dm.find_missing_python_packages()
    if not missing:
        missing = ["streamlit"]

    ok = dm.install_python_packages(missing, log=print)

    if not ok:
        _print_box(
            "MEANCURE - Setup failed",
            [
                "Failed to install required Python packages automatically.",
                f"Python used: {sys.executable}",
                "",
                "Please open a terminal and run manually:",
                f'  "{sys.executable}" -m pip install -r requirements.txt',
                "",
                "If pip itself is missing, install it first, e.g.:",
                "  sudo apt-get install python3-pip     # Debian/Ubuntu",
                "  sudo dnf install python3-pip          # Fedora",
            ],
        )
        sys.exit(1)

    try:
        import streamlit  # noqa: F401
    except ImportError:
        _print_box(
            "MEANCURE - Setup failed",
            ["streamlit was installed but still could not be imported.",
             "Please check your Python installation."],
        )
        sys.exit(1)


def _check_blast_binaries() -> None:
    """
    Non-fatal — the app launches regardless, and the Dependencies page
    inside the app will keep showing the same instructions until this is
    resolved. This just saves the user a click on first run.
    """
    import dependency_manager as dm

    missing = [s.name for s in dm.check_all_binaries() if not s.found]
    if not missing:
        return

    print(f"\n⚠️  BLAST+ not found on PATH: {', '.join(missing)}")
    print("The BLAST step will fail until this is installed.\n")
    print(dm.get_blast_install_instructions())
    print()


def _open_browser_later(url: str) -> None:
    def _later():
        time.sleep(2.5)
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass
    threading.Thread(target=_later, daemon=True).start()


def main() -> None:
    _check_app_dir()
    os.chdir(APP_DIR)
    _check_python_version()
    _ensure_packages_installed()
    _check_blast_binaries()

    port = os.environ.get("MBP_PORT", "8501")
    url = f"http://localhost:{port}"

    print(f"Starting MEANCURE — open {url} in your browser if it doesn't open automatically.")
    print("Press Ctrl+C in this terminal to stop the app.\n")

    has_display = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    if has_display or platform.system() == "Darwin":
        _open_browser_later(url)
    else:
        print("(No graphical display detected — open the URL above manually, "
              "e.g. via SSH port forwarding if running on a remote server.)\n")

    sys.argv = [
        "streamlit", "run", str(APP_DIR / "app.py"),
        "--server.port", port,
        "--server.headless", "true",
        "--theme.base", "light",
    ]
    from streamlit.web import cli as stcli
    sys.exit(stcli.main())


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nMEANCURE stopped.")
        sys.exit(0)