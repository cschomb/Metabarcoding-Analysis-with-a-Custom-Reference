from __future__ import annotations

import math
import os
import platform
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import folium
import numpy as np
import pandas as pd
import streamlit as st
from pyproj import Geod
from streamlit_folium import st_folium

import pipeline as pl
import winproc

SHEET_NAMES = ["blast", "analysis", "gbif"]

SETTINGS_SESSION_KEYS = {
    "blast": "blast_settings",
    "analysis": "analysis_settings",
    "gbif": "gbif_settings",
}


# =============================================================================
# Mandatory settings validation
# =============================================================================

MANDATORY_FIELDS = {
    "blast": {
        "reference_fasta": "Reference FASTA",
        "esv_fasta": "ESV sequences (query FASTA)",
    },
    "analysis": {
        "esv_table": "ESV table",
    },
    "gbif": {
        "year_from": "year_from",
        "lon": "Longitude (lon)",
        "lat": "Latitude (lat)",
        "radius_m": "radius_m",
    },
}

# Fields that represent a FILE selection — these need an existence check on
# disk, not just a non-empty value, because write_settings_template() fills
# them with placeholder filenames (e.g. "reference.fasta") that don't
# actually exist until the user uploads something.
FILE_FIELDS = {
    "blast": {"reference_fasta", "esv_fasta"},
    "analysis": {"esv_table", "blast_results"},
    "gbif": {"input_results_xlsx"},
}


def is_file_setting_missing(paths: pl.ProjectPaths, value, default_dir: Path) -> bool:
    """True if empty, OR a non-empty value that points to a file that
    doesn't actually exist (e.g. an untouched template placeholder)."""
    if pl._is_empty(value):
        return True
    try:
        resolved = pl.resolve_path_setting(paths, value, default_dir)
    except Exception:
        return True
    return not resolved.exists()


def validate_settings(
    paths: pl.ProjectPaths,
    blast_settings: dict,
    analysis_settings: dict,
    gbif_settings: dict,
    run_flags: dict,
) -> dict[str, dict[str, str]]:
    """
    Checks mandatory fields, but ONLY for steps that are currently enabled
    via run_flags. File-type fields are checked for existence on disk, not
    just non-emptiness (template placeholders are non-empty but don't
    exist as real files yet).

    Returns {sheet: {parameter: human_label}} — only sheets with at least
    one missing field are included. Empty dict == fully valid.
    """
    missing: dict[str, dict[str, str]] = {"blast": {}, "analysis": {}, "gbif": {}}

    def _check(sheet: str, settings_dict: dict, param: str, label: str) -> None:
        if param in FILE_FIELDS.get(sheet, set()):
            if is_file_setting_missing(paths, settings_dict.get(param), paths.input):
                missing[sheet][param] = label
        else:
            if pl._is_empty(settings_dict.get(param)):
                missing[sheet][param] = label

    if run_flags.get("run_blast", True):
        for param, label in MANDATORY_FIELDS["blast"].items():
            _check("blast", blast_settings, param, label)

    if run_flags.get("run_analysis", True):
        for param, label in MANDATORY_FIELDS["analysis"].items():
            _check("analysis", analysis_settings, param, label)
        if not run_flags.get("run_blast", True):
            _check(
                "analysis", analysis_settings, "blast_results",
                "Existing BLAST output (required — BLAST step is disabled)",
            )

    if run_flags.get("run_gbif", True):
        for param, label in MANDATORY_FIELDS["gbif"].items():
            _check("gbif", gbif_settings, param, label)
        if not run_flags.get("run_analysis", True):
            _check(
                "gbif", gbif_settings, "input_results_xlsx",
                "Existing results file (required — Analysis step is disabled)",
            )

    return {sheet: fields for sheet, fields in missing.items() if fields}


def validate_input_files(
    paths: pl.ProjectPaths,
    blast_settings: dict,
    analysis_settings: dict,
    gbif_settings: dict,
    run_flags: dict,
) -> dict[str, dict[str, str]]:
    """
    Same rules as validate_settings(), narrowed down to only the fields
    that represent an actual input file selection — for the Input Files
    page and the file-specific box on Run Pipeline.
    """
    missing = validate_settings(paths, blast_settings, analysis_settings, gbif_settings, run_flags)
    filtered: dict[str, dict[str, str]] = {}
    for sheet, fields in missing.items():
        wanted = FILE_FIELDS.get(sheet, set())
        kept = {k: v for k, v in fields.items() if k in wanted}
        if kept:
            filtered[sheet] = kept
    return filtered


def format_missing_settings(missing: dict[str, dict[str, str]]) -> str:
    titles = {"blast": "🔵 BLAST", "analysis": "🟢 Analysis", "gbif": "🟣 GBIF"}
    lines = []
    for sheet, fields in missing.items():
        lines.append(f"**{titles.get(sheet, sheet)}**")
        for label in fields.values():
            lines.append(f"- {label}")
    return "\n".join(lines)


def mandatory_label(label: str) -> str:
    """Appends a required-field marker to a widget label."""
    return f"{label}  :red[*]"


def show_required_marker(value) -> None:
    """Call right after a mandatory NON-FILE widget to flag it if empty."""
    if pl._is_empty(value):
        st.caption(":red[⚠️ Required]")


def show_required_file_marker(paths: pl.ProjectPaths, value, default_dir: Path) -> None:
    """Call right after a mandatory FILE widget — flags it if the selected
    value is empty OR points to a file that doesn't exist on disk."""
    if is_file_setting_missing(paths, value, default_dir):
        st.caption(":red[⚠️ Required — file not found in input/]")


# =============================================================================
# Session state
# =============================================================================

def init_session_state() -> None:
    ss = st.session_state
    ss.setdefault("paths", None)
    ss.setdefault("base_dir", str(Path.home()))
    ss.setdefault("project_name", "my_project")


def get_paths() -> pl.ProjectPaths | None:
    return st.session_state.get("paths")


def require_paths() -> pl.ProjectPaths:
    paths = get_paths()
    if paths is None:
        st.warning("⚠️ No active project. Go to **Project Setup** first.")
        st.stop()
    return paths


require_project = require_paths


def as_text(value) -> str:
    return "" if pl._is_empty(value) else str(value)

def normalize_decimal_input(text: str) -> str:
    """
    Converts a European-style decimal comma to a period, e.g. "50,1109" ->
    "50.1109" — only when the string looks like a single plain decimal
    number (exactly one comma, no period already present), so nothing
    else gets mangled.
    """
    s = (text or "").strip()
    if s.count(",") == 1 and "." not in s:
        s = s.replace(",", ".")
    return s


# =============================================================================
# Project-scoped settings dicts (in-memory working copy)
# =============================================================================

def init_default_settings(force_reload: bool = False) -> None:
    paths = get_paths()
    if paths is None:
        return

    loaded_for = st.session_state.get("settings_loaded_for")
    already_loaded = all(k in st.session_state for k in SETTINGS_SESSION_KEYS.values())

    if not force_reload and already_loaded and loaded_for == str(paths.root):
        return

    for sheet, ss_key in SETTINGS_SESSION_KEYS.items():
        st.session_state[ss_key] = pl.read_sheet_kv(paths, sheet)

    st.session_state["run_flags"] = {
        "run_blast": True,
        "run_analysis": True,
        "run_gbif": True,
    }

    st.session_state["settings_loaded_for"] = str(paths.root)


def save_settings_to_disk(paths: pl.ProjectPaths) -> None:
    def kv_df(d: dict) -> pd.DataFrame:
        values = ["" if pl._is_empty(v) else str(v) for v in d.values()]
        return pd.DataFrame({"parameter": list(d.keys()), "value": values})

    with pd.ExcelWriter(paths.settings, engine="openpyxl") as xw:
        for sheet, ss_key in SETTINGS_SESSION_KEYS.items():
            kv_df(st.session_state[ss_key]).to_excel(xw, sheet_name=sheet, index=False)

    pl.force_value_column_text_format(paths.settings, SHEET_NAMES)

def set_setting_value(paths: pl.ProjectPaths, sheet: str, parameter: str, value) -> None:
    init_default_settings()
    ss_key = SETTINGS_SESSION_KEYS[sheet]
    st.session_state[ss_key][parameter] = "" if pl._is_empty(value) else str(value)
    save_settings_to_disk(paths)


# =============================================================================
# File discovery helpers (for file-picker dropdowns)
# =============================================================================

def list_files(folder: Path, extensions: tuple[str, ...]) -> list[str]:
    if not folder.exists():
        return []
    return sorted(
        f.name for f in folder.iterdir()
        if f.is_file() and f.suffix.lower() in extensions
    )


def pick_file(label: str, options: list[str], current_value, key: str) -> str:
    current = as_text(current_value)
    opts = list(options)
    if current and current not in opts:
        opts = [current] + opts
    if not opts:
        opts = ["<no files found>"]

    index = opts.index(current) if current in opts else 0
    choice = st.selectbox(label, opts, index=index, key=key)
    return "" if choice == "<no files found>" else choice


def rel_to_root(paths: pl.ProjectPaths, abspath: Path) -> str:
    try:
        rel = abspath.resolve().relative_to(paths.root.resolve())
        return rel.as_posix()
    except ValueError:
        return str(abspath)


# =============================================================================
# Stage + progress tracking (thread-safe, NOT st.session_state — see notes
# in start_step/render_live_log about why worker threads can't touch
# st.session_state directly)
# =============================================================================

STAGE_LABELS = {
    "blast": "🧬 BLAST",
    "analysis": "📊 Analysis",
    "gbif": "🌍 GBIF",
}

STAGE_MARKERS = [
    ("STEP 1: RUNNING BLAST", "blast"),
    ("STEP 2: ANALYSIS", "analysis"),
    ("STEP 3: GBIF OCCURRENCE", "gbif"),
    ("PIPELINE FINISHED.", "done"),
]

_stage_lock = threading.Lock()
_stage_state: dict[str, str] = {}

_progress_lock = threading.Lock()
_progress_state: dict[str, dict] = {}
_last_progress_report_ts = 0.0


def _set_stage(step_key: str, stage: str) -> None:
    with _stage_lock:
        _stage_state[step_key] = stage


def get_stage(step_key: str) -> str | None:
    with _stage_lock:
        return _stage_state.get(step_key)


def clear_stage(step_key: str) -> None:
    with _stage_lock:
        _stage_state.pop(step_key, None)


def _report_progress(bar, finished: bool = False) -> None:
    global _last_progress_report_ts
    now = time.monotonic()
    if not finished and (now - _last_progress_report_ts) < 0.3:
        return
    _last_progress_report_ts = now
    try:
        d = bar.format_dict
    except Exception:
        return
    with _progress_lock:
        _progress_state["pipeline"] = {
            "desc": getattr(bar, "desc", "") or "",
            "n": d.get("n", 0) or 0,
            "total": d.get("total"),
            "rate": d.get("rate"),
            "elapsed": d.get("elapsed", 0) or 0,
            "finished": finished,
        }


def get_progress(step_key: str) -> dict:
    with _progress_lock:
        return dict(_progress_state.get(step_key, {}))


def clear_progress(step_key: str) -> None:
    with _progress_lock:
        _progress_state.pop(step_key, None)


def patch_pipeline_hooks() -> None:
    """
    Monkey-patches pipeline.py's `tqdm` and `log` so progress bars and
    stage transitions become visible to the Streamlit UI, via thread-safe
    plain-Python state rather than st.session_state.
    """
    if getattr(pl, "_hooks_patched", False):
        return

    from tqdm import tqdm as _tqdm

    class _PatchedTqdm(_tqdm):
        def __init__(self, *args, **kwargs):
            kwargs.setdefault("mininterval", 1.0)
            kwargs.setdefault("dynamic_ncols", False)
            kwargs.setdefault("ascii", True)
            super().__init__(*args, **kwargs)
            _report_progress(self)

        def update(self, n=1):
            result = super().update(n)
            _report_progress(self)
            return result

        def close(self):
            _report_progress(self, finished=True)
            return super().close()

    pl.tqdm = _PatchedTqdm

    _orig_log = pl.log

    def _patched_log(paths, msg):
        _orig_log(paths, msg)
        text = str(msg)
        for marker, stage in STAGE_MARKERS:
            if marker in text:
                _set_stage("pipeline", stage)
                break

    pl.log = _patched_log

    pl._hooks_patched = True


# =============================================================================
# Background step execution
# =============================================================================
#
# IMPORTANT: st.session_state must only be touched from the Streamlit
# script-execution thread that owns it. Background worker threads have no
# ScriptRunContext, so writing to st.session_state from inside them silently
# resolves to a different, uninitialized session object and raises KeyError.
#
# All run-tracking state therefore lives in plain module-level, thread-safe
# dictionaries here instead of in st.session_state.

_run_lock = threading.Lock()
_run_threads: dict[str, threading.Thread] = {}
_run_errors: dict[str, str | None] = {}
_run_results: dict[str, object] = {}
_run_done: dict[str, bool] = {}
_run_aborted: dict[str, bool] = {}

_abort_lock = threading.Lock()
_abort_flags: dict[str, bool] = {}


def request_abort(step_key: str) -> None:
    with _abort_lock:
        _abort_flags[step_key] = True


def is_abort_requested(step_key: str) -> bool:
    with _abort_lock:
        return _abort_flags.get(step_key, False)


def clear_abort(step_key: str) -> None:
    with _abort_lock:
        _abort_flags[step_key] = False


def was_aborted(step_key: str) -> bool:
    return _run_aborted.get(step_key, False)


def is_running(step_key: str) -> bool:
    t = _run_threads.get(step_key)
    return t is not None and t.is_alive()


def has_run(step_key: str) -> bool:
    return step_key in _run_threads


def start_step(step_key: str, target, *args, **kwargs) -> None:
    if is_running(step_key):
        return

    with _run_lock:
        _run_errors[step_key] = None
        _run_done[step_key] = False
        _run_aborted[step_key] = False

    clear_stage(step_key)
    clear_progress(step_key)
    clear_abort(step_key)

    def _wrapper():
        try:
            pl.RUN_TS = datetime.now().strftime("%Y%m%d_%H%M%S")
            result = target(*args, **kwargs)
            with _run_lock:
                _run_results[step_key] = result
        except pl.PipelineAborted as e:
            with _run_lock:
                _run_aborted[step_key] = True
                _run_errors[step_key] = str(e)
        except Exception as e:  # noqa: BLE001
            with _run_lock:
                _run_errors[step_key] = str(e)
        finally:
            with _run_lock:
                _run_done[step_key] = True

    t = threading.Thread(target=_wrapper, daemon=True)
    _run_threads[step_key] = t
    t.start()


def _format_eta(n: int, total: int, rate: float | None) -> str:
    if not rate or not total:
        return ""
    remaining = max(total - n, 0)
    secs = remaining / rate
    return f"{secs:.0f}s" if secs < 60 else f"{secs / 60:.1f}min"


def render_live_log(
    paths: pl.ProjectPaths,
    step_key: str,
    active_steps: list[str] | None = None,
    poll_interval: float = 1.0,
) -> None:
    t = _run_threads.get(step_key)
    if t is None:
        return

    stage_box = st.empty()
    progress_box = st.empty()

    st.caption("Log output")
    log_container = st.container(height=300, border=True)
    log_box = log_container.empty()

    status_box = st.empty()

    def _draw():
        if active_steps:
            stage = get_stage(step_key)
            stage_order = list(STAGE_LABELS)
            done = stage == "done"
            stage_idx = stage_order.index(stage) if (stage and stage in stage_order) else -1

            parts = []
            for s in active_steps:
                label = STAGE_LABELS.get(s, s)
                if done or (stage_idx >= 0 and stage_order.index(s) < stage_idx):
                    label = f"✅ {label}"
                elif s == stage:
                    label = f"**➡️ {label}**"
                parts.append(label)
            stage_box.markdown(" &nbsp;→&nbsp; ".join(parts))

        prog = get_progress(step_key)
        if prog and not prog.get("finished"):
            n, total, rate = prog.get("n", 0), prog.get("total"), prog.get("rate")
            desc = prog.get("desc") or "Working"
            rate_str = f"{rate:.1f}/s" if rate else ""
            if total:
                frac = min(n / total, 1.0)
                eta = _format_eta(n, total, rate)
                text = f"{desc}: {n}/{total}" + (f" · {rate_str}" if rate_str else "") + (f" · ETA {eta}" if eta else "")
                progress_box.progress(frac, text=text)
            else:
                progress_box.progress(0, text=f"{desc}: {n} processed" + (f" · {rate_str}" if rate_str else ""))
        else:
            progress_box.empty()

        if paths.logfile.exists():
            log_box.code(paths.logfile.read_text(encoding="utf-8")[-6000:], language="text")

    while t.is_alive():
        _draw()
        if is_abort_requested(step_key):
            status_box.warning(
                "🛑 Stop requested — waiting for the current step to finish "
                "(current BLAST chunk or API call)..."
            )
        else:
            status_box.info("⏳ Running…")
        time.sleep(poll_interval)

    _draw()

    aborted = was_aborted(step_key)
    err = _run_errors.get(step_key)
    if aborted:
        status_box.warning("🛑 Pipeline aborted by user.")
    elif err:
        status_box.error(f"❌ Failed: {err}")
    else:
        status_box.success("✅ Finished.")

def render_file_list(folder: Path, pattern: str, empty_msg: str = "No files yet.", preview: bool = False) -> None:
    files = sorted(folder.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        st.write(empty_msg)
        return
    for f in files:
        c1, c2 = st.columns([3, 1])
        c1.write(f"`{f.name}`")
        c2.download_button(
            "Download", f.read_bytes(), file_name=f.name,
            key=f"dl_{folder.parent.name}_{pattern}_{f.name}",
        )
        if preview and f.suffix.lower() in (".xlsx", ".csv"):
            with st.expander(f"👁️ Preview {f.name}"):
                try:
                    df_preview = pd.read_excel(f) if f.suffix.lower() == ".xlsx" else pd.read_csv(f)
                    st.caption(f"{len(df_preview)} rows × {len(df_preview.columns)} columns (showing first 200 rows)")
                    st.dataframe(df_preview.head(200), use_container_width=True)
                except Exception as e:  # noqa: BLE001
                    st.warning(f"Could not preview file: {e}")

# =============================================================================
# WSL-aware native folder picker
# =============================================================================

def is_wsl() -> bool:
    if platform.system() != "Linux":
        return False
    if os.environ.get("WSL_DISTRO_NAME"):
        return True
    try:
        with open("/proc/version", encoding="utf-8", errors="ignore") as fh:
            v = fh.read().lower()
        return "microsoft" in v or "wsl" in v
    except OSError:
        return False


def _powershell_available() -> bool:
    return shutil.which("powershell.exe") is not None


def has_display() -> bool:
    if platform.system() != "Linux":
        return True
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def tkinter_available() -> tuple[bool, str]:
    try:
        if getattr(sys, "frozen", False):
            cmd = [sys.executable, "--internal-check-tkinter"]
        else:
            cmd = [sys.executable, "-c", "import tkinter"]
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
            **winproc.no_window_kwargs(),
        )
        if result.returncode == 0:
            return True, ""
        return False, (result.stderr or "unknown import error").strip()
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def folder_picker_status() -> tuple[bool, str, str]:
    if is_wsl():
        if _powershell_available():
            return True, "", "wsl-powershell"
        return False, (
            "Running under WSL, but powershell.exe is not reachable. "
            "WSL interop may be disabled (check /etc/wsl.conf for "
            "[interop] enabled=false). Type the path manually below — "
            "use /mnt/c/Users/<you>/... style paths to reach your "
            "Windows files."
        ), ""

    if not has_display():
        return False, (
            "No graphical display detected (DISPLAY / WAYLAND_DISPLAY not set). "
            "This usually means you're on a headless server or connected via "
            "SSH without X11 forwarding. Type the path manually below."
        ), ""

    ok, err = tkinter_available()
    if not ok:
        return False, (
            "tkinter is not installed for this Python interpreter.\n\n"
            "Install it with:\n"
            "  sudo apt-get install python3-tk      # Debian/Ubuntu\n"
            "  sudo dnf install python3-tkinter      # Fedora\n"
            "  sudo pacman -S tk                     # Arch\n\n"
            f"(Underlying error: {err})"
        ), ""

    return True, "", "tkinter"


def _wslpath(path: str, to_windows: bool) -> str | None:
    flag = "-w" if to_windows else "-u"
    try:
        result = subprocess.run(
            ["wslpath", flag, path], capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None


def _pick_directory_windows_native(initial_dir_wsl: str) -> tuple[str | None, str | None]:
    win_initial = _wslpath(initial_dir_wsl, to_windows=True) or ""
    init_line = ""
    if win_initial:
        safe = win_initial.replace('"', '`"')
        init_line = f'$f.SelectedPath = "{safe}"\n'

    ps_script = (
        "Add-Type -AssemblyName System.Windows.Forms\n"
        "$f = New-Object System.Windows.Forms.FolderBrowserDialog\n"
        "$f.Description = 'Select a project base directory'\n"
        f"{init_line}"
        "if ($f.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) "
        "{ Write-Output $f.SelectedPath }\n"
    )

    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-STA", "-Command", ps_script],
            capture_output=True, text=True, timeout=120,
            **winproc.no_window_kwargs(),
        )
    except subprocess.TimeoutExpired:
        return None, "Windows folder dialog timed out after 120s."
    except Exception as e:  # noqa: BLE001
        return None, f"Failed to launch powershell.exe: {e}"

    if result.returncode != 0:
        return None, (result.stderr.strip() or "Unknown PowerShell error.")

    win_path = result.stdout.strip()
    if not win_path:
        return None, None

    wsl_path = _wslpath(win_path, to_windows=False)
    if wsl_path is None:
        return None, f"Got Windows path '{win_path}' but wslpath conversion failed."
    return wsl_path, None


def _pick_directory_tkinter(initial_dir: str) -> tuple[str | None, str | None]:
    script = (
        "import sys, tkinter as tk\n"
        "from tkinter import filedialog\n"
        "try:\n"
        "    root = tk.Tk()\n"
        "    root.withdraw()\n"
        "    root.attributes('-topmost', True)\n"
        "    root.lift()\n"
        "    root.focus_force()\n"
        f"    path = filedialog.askdirectory(initialdir={initial_dir!r}, parent=root)\n"
        "    root.attributes('-topmost', False)\n"
        "    print('RESULT:' + path)\n"
        "except Exception as e:\n"
        "    print('ERROR:' + str(e), file=sys.stderr)\n"
        "    sys.exit(1)\n"
    )
    try:
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True, text=True, timeout=120,
            **winproc.no_window_kwargs(),
        )
    except subprocess.TimeoutExpired:
        return None, "Dialog timed out after 120s."
    except Exception as e:  # noqa: BLE001
        return None, f"Failed to launch folder dialog subprocess: {e}"

    if result.returncode != 0:
        return None, (result.stderr.strip() or "Unknown error.")

    out = result.stdout.strip()
    if out.startswith("RESULT:"):
        path = out[len("RESULT:"):]
        return (path or None), None
    return None, f"Unexpected dialog output: {out!r}"


def pick_directory_dialog(initial_dir: str = ".") -> tuple[str | None, str | None]:
    usable, reason, method = folder_picker_status()
    if not usable:
        return None, reason
    if method == "wsl-powershell":
        return _pick_directory_windows_native(initial_dir)
    return _pick_directory_tkinter(initial_dir)


# =============================================================================
# GBIF search-circle map — interactive click-to-set-coordinates
# =============================================================================

def _estimate_zoom(radius_m: float) -> float:
    if radius_m <= 0:
        return 10.0
    zoom = 14 - math.log2(max(radius_m, 1) / 500)
    return float(max(2.0, min(16.0, zoom)))


def render_gbif_click_map(
    lat: float | None,
    lon: float | None,
    radius_m: float,
    n_points: int,
    key: str = "gbif_click_map",
) -> tuple[float, float] | None:
    have_center = lat is not None and lon is not None

    if have_center:
        center = [lat, lon]
        zoom = int(round(_estimate_zoom(radius_m)))
    else:
        center = [20.0, 0.0]
        zoom = 2

    m = folium.Map(location=center, zoom_start=zoom, control_scale=True)

    if have_center:
        folium.Marker(
            [lat, lon],
            tooltip="Center point (click map elsewhere to move it)",
            icon=folium.DivIcon(
                html='<div style="font-size: 28px; transform: translate(-50%, -100%);">📌</div>',
                icon_size=(0, 0),   # let the div size itself, position via transform
            ),
        ).add_to(m)

        geod = Geod(ellps="WGS84")
        bearings = np.linspace(0, 360, max(int(n_points), 3), endpoint=True)
        for b in bearings:
            x, y, _ = geod.fwd(lon, lat, b, radius_m)
            folium.CircleMarker(
                location=[y, x],
                radius=5,
                color="green",
                fill=True,
                fill_color="green",
                fill_opacity=0.9,
            ).add_to(m)

    result = st_folium(m, height=800, use_container_width=True, key=key, returned_objects=["last_clicked"])

    clicked = (result or {}).get("last_clicked")
    if clicked:
        return float(clicked["lat"]), float(clicked["lng"])
    return None