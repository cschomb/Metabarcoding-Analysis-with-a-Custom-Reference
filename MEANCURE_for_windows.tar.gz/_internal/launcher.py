#!/usr/bin/env python3
"""
Entry point launched by MEANCURE.vbs, using the user's own Python
installation (no bundled Python runtime). Only the BLAST+ binaries in
./bin are bundled with the app.
"""
from __future__ import annotations

import os
import sys
import time
import threading
import subprocess
from pathlib import Path
import winproc

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

REQUIREMENTS_FILE = APP_DIR / "requirements.txt"
MIN_PYTHON = (3, 9)

def _fix_std_streams() -> None:
    """
    pythonw.exe / pyw.exe have no console attached, so Windows gives the
    process no stdout/stderr handles at all — Python sets them to None.
    Any code that calls print() or tqdm.write() then crashes with:
        'NoneType' object has no attribute 'write'
    Redirect them to a small log file instead, so nothing crashes and we
    still capture anything printed outside of pipeline.log()'s own file.
    """
    if sys.stdout is not None and sys.stderr is not None:
        return
    try:
        stream = open(
            APP_DIR / "stdout_stderr.log", "a", buffering=1,
            encoding="utf-8", errors="replace",
        )
    except Exception:
        import io
        stream = io.StringIO()
    if sys.stdout is None:
        sys.stdout = stream
    if sys.stderr is None:
        sys.stderr = stream


def _fatal_message(title: str, message: str) -> None:
    """
    Show an error dialog even though we're launched via pythonw.exe
    (no console attached). Also appends to crash_log.txt as a fallback.
    """
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(title, message)
        root.destroy()
    except Exception:
        pass
    try:
        with open(APP_DIR / "crash_log.txt", "a", encoding="utf-8") as f:
            f.write(f"\n[{title}]\n{message}\n")
    except Exception:
        pass


def _check_python_version() -> None:
    if sys.version_info < MIN_PYTHON:
        _fatal_message(
            "MEANCURE - Unsupported Python version",
            "MEANCURE requires Python "
            f"{MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer.\n\n"
            f"Found: {sys.version.split()[0]} ({sys.executable})\n\n"
            "Please install a newer Python from https://www.python.org/downloads/",
        )
        sys.exit(1)


def _ensure_streamlit_installed() -> None:
    """
    The bundled Python used to ship with everything pre-installed.
    Now that users provide their own Python, bootstrap streamlit (and the
    rest of requirements.txt) with pip on first run if it's missing.
    """
    try:
        import streamlit  # noqa: F401
        return
    except ImportError:
        pass

    wait_win = None
    try:
        import tkinter as tk
        wait_win = tk.Tk()
        wait_win.title("MEANCURE - First-time setup")
        wait_win.geometry("380x110")
        wait_win.resizable(False, False)
        tk.Label(
            wait_win,
            text="Installing required Python packages...\nThis can take a minute.",
            font=("Segoe UI", 10),
        ).pack(expand=True, pady=20)
        wait_win.update()
    except Exception:
        wait_win = None

    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"]
    cmd += ["-r", str(REQUIREMENTS_FILE)] if REQUIREMENTS_FILE.exists() else ["streamlit"]
    proc = subprocess.run(cmd, capture_output=True, text=True, **winproc.no_window_kwargs())

    if wait_win is not None:
        try:
            wait_win.destroy()
        except Exception:
            pass

    if proc.returncode != 0:
        _fatal_message(
            "MEANCURE - Setup failed",
            "Failed to install required Python packages automatically.\n\n"
            f"Python used: {sys.executable}\n\n"
            "Please open a terminal and run manually:\n"
            f'  "{sys.executable}" -m pip install -r requirements.txt\n\n'
            f"{(proc.stdout or '')[-1500:]}\n{(proc.stderr or '')[-1500:]}",
        )
        sys.exit(1)

    try:
        import streamlit  # noqa: F401
    except ImportError:
        _fatal_message(
            "MEANCURE - Setup failed",
            "streamlit was installed but still could not be imported. "
            "Please check your Python installation.",
        )
        sys.exit(1)


def _run_control_ui(url: str) -> None:
    def _open_later():
        time.sleep(2.5)
        import webbrowser
        webbrowser.open(url)
    threading.Thread(target=_open_later, daemon=True).start()

    try:
        import tkinter as tk
    except Exception:
        return

    root = tk.Tk()
    root.title("MEANCURE")
    root.geometry("380x170")
    root.resizable(False, False)

    icon_path = APP_DIR / "assets" / "icon.ico"
    if icon_path.exists():
        try:
            root.iconbitmap(str(icon_path))
        except Exception:
            pass

    tk.Label(root, text="MEANCURE is running.", font=("Segoe UI", 11, "bold")).pack(pady=(16, 6))
    tk.Label(root, text=url, font=("Segoe UI", 9)).pack()
    tk.Label(root, text=f"Python: {sys.executable}", font=("Segoe UI", 8), fg="gray").pack(pady=(2, 0))
    tk.Label(
        root, text="Closing this window will stop the app.",
        font=("Segoe UI", 9), fg="gray",
    ).pack(pady=(6, 10))

    def _open():
        import webbrowser
        webbrowser.open(url)
    tk.Button(root, text="Open in browser", command=_open).pack()

    def _on_close():
        os._exit(0)
    root.protocol("WM_DELETE_WINDOW", _on_close)
    root.mainloop()


def main() -> None:
    os.chdir(APP_DIR)
    _fix_std_streams()
    _check_python_version()
    _ensure_streamlit_installed()

    port = os.environ.get("MBP_PORT", "8501")
    url = f"http://localhost:{port}"

    ui_thread = threading.Thread(target=_run_control_ui, args=(url,), daemon=True)
    ui_thread.start()

    sys.argv = [
        "streamlit", "run", str(APP_DIR / "app.py"),
        "--server.port", port,
        "--server.headless", "true",
    ]
    from streamlit.web import cli as stcli
    sys.exit(stcli.main())


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        import traceback
        tb = traceback.format_exc()
        try:
            with open(APP_DIR / "crash_log.txt", "w", encoding="utf-8") as f:
                f.write(tb)
        except Exception:
            pass
        _fatal_message("MEANCURE - Crashed", tb[-3000:])
        raise