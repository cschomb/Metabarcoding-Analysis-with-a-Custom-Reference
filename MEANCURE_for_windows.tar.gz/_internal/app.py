from __future__ import annotations

from pathlib import Path

import streamlit as st
import dependency_manager as dm
import branding

_icon_path = Path(__file__).parent / "assets" / "icon.png"
st.set_page_config(
    page_title="Metabarcoding Pipeline",
    layout="wide",
    page_icon=str(_icon_path) if _icon_path.exists() else "🧬",
)

branding.render_branding()

st.session_state.setdefault("dep_auto_attempted", False)
st.session_state.setdefault("dep_log", [])


def _dep_log(msg):
    if msg:
        st.session_state["dep_log"].append(str(msg))


# --- Python package check: cached per session (cheap, but avoid repeats) ---
if "missing_py_cache" not in st.session_state:
    st.session_state["missing_py_cache"] = dm.find_missing_python_packages()
missing_py = st.session_state["missing_py_cache"]

if missing_py and not st.session_state["dep_auto_attempted"]:
    st.session_state["dep_auto_attempted"] = True
    with st.spinner("🔧 First-time setup — installing missing Python packages..."):
        _dep_log(f"Installing: {missing_py}")
        dm.install_python_packages(missing_py, _dep_log)
        st.session_state["missing_py_cache"] = dm.find_missing_python_packages()
        missing_py = st.session_state["missing_py_cache"]
    st.rerun()

dependencies_page = st.Page("pages/0_dependencies.py", title="(Dependencies)", icon="🔧")

if missing_py:
    st.sidebar.error(
        "❌ Missing required Python packages: " + ", ".join(missing_py) +
        "\n\nOpen **Dependencies** to retry, or install manually "
        f"(`pip install {' '.join(missing_py)}`)."
    )
    pg = st.navigation([dependencies_page])
    pg.run()
    st.stop()

import common  # noqa: E402

common.init_session_state()

pages = {
    "Setup": [        
        st.Page("pages/1_project_setup.py", title="Project Setup", icon="📁"),
        st.Page("pages/2_input_files.py", title="Input Files", icon="📤"),
        st.Page("pages/3_settings.py", title="Settings", icon="⚙️"),
        dependencies_page,
    ],
    "Pipeline": [
        st.Page("pages/4_run_pipeline.py", title="Run Pipeline", icon="▶"),
    ],
    "Output": [
        st.Page("pages/5_results.py", title="Results & Logs", icon="📈"),
    ],
}

# Register navigation as early as possible, so the sidebar shows the real
# pages + icons immediately — instead of the generic "app" placeholder
# persisting while slower checks (spawning BLAST+ subprocesses) still run.
pg = st.navigation(pages)

# --- BLAST+ binary check: cached per session, deliberately placed AFTER
# st.navigation() so subprocess calls never delay the sidebar nav. ---
if "missing_bin_cache" not in st.session_state:
    st.session_state["missing_bin_cache"] = [
        s.name for s in dm.check_all_binaries() if not s.found
    ]
missing_bin = st.session_state["missing_bin_cache"]

if missing_bin:
    st.sidebar.warning(
        "⚠️ BLAST+ not found on PATH: " + ", ".join(missing_bin) +
        " — the BLAST step will fail until this is installed. "
        "See the Dependencies page for instructions."
    )

pg.run()