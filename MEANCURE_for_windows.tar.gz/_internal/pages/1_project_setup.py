from __future__ import annotations

from pathlib import Path

import streamlit as st
import pipeline as pl
import common

common.init_session_state()
st.title("📁 Project Setup")

base_dir = st.text_input(
    "Base directory (the project folder will be created inside this)",
    value=st.session_state["base_dir"],
)
st.session_state["base_dir"] = base_dir

usable, reason, method = common.folder_picker_status()

if not usable:
    with st.expander("📂 Folder picker unavailable — click for details"):
        st.warning(reason)
else:
    label = (
        "📂 Browse for folder..."        
    )
    if st.button(label):
        with st.spinner("Waiting for folder dialog..."):
            picked, error = common.pick_directory_dialog(initial_dir=base_dir)
        if error:
            st.error(f"Folder picker failed:\n\n{error}")
        elif picked:
            st.session_state["base_dir"] = picked
            st.rerun()
        else:
            st.info("Folder selection cancelled.")

if common.is_wsl():
    st.caption(
        "💡 WSL tip: for better performance, prefer a Linux-native path "
        "(e.g. `~/projects/...`) over a Windows drive path "
        "(`/mnt/c/Users/...`) — files on `/mnt/c` are accessed through a "
        "slower network-filesystem bridge, which matters for large BLAST "
        "databases and FASTA files."
    )

base_path = Path(base_dir).expanduser()

existing_projects = []
if base_path.exists() and base_path.is_dir():
    for child in sorted(base_path.iterdir()):
        if child.is_dir() and (child / "settings.xlsx").exists():
            existing_projects.append(child.name)

if existing_projects:
    st.caption(f"Existing projects found in `{base_path}`:")
    picked_existing = st.selectbox(
        "Quick-select an existing project", ["(new project)"] + existing_projects
    )
else:
    picked_existing = "(new project)"

default_name = (
    picked_existing if picked_existing != "(new project)" else st.session_state["project_name"]
)
project_name = st.text_input("Project folder name", value=default_name)
st.session_state["project_name"] = project_name

root = (base_path / project_name).resolve()
st.caption(f"Full project path: `{root}`")

force_init = st.checkbox("Overwrite settings.xlsx if it already exists", value=False)

c1, c2 = st.columns(2)

if c1.button("🆕 Initialise new project", type="primary"):
    paths = pl.ProjectPaths(root)
    pl.ensure_structure(paths)
    try:
        pl.write_settings_template(paths, force=force_init)
        st.success(f"Initialised project at: {root}")
    except FileExistsError as e:
        st.warning(str(e))
    st.session_state["paths"] = paths
    st.session_state.pop("settings_loaded_for", None)  # force fresh settings load

if c2.button("📂 Load existing project"):
    paths = pl.ProjectPaths(root)
    if not paths.settings.exists():
        st.error("settings.xlsx not found in that folder — initialise it first.")
    else:
        pl.ensure_structure(paths)
        st.session_state["paths"] = paths
        st.session_state.pop("settings_loaded_for", None)  # force fresh settings load
        st.success(f"Loaded project: {root}")

paths = common.get_paths()
if paths:
    st.divider()
    st.subheader("Active project")
    st.code(str(paths.root))
    st.json({
        "input": str(paths.input),
        "01_blast": str(paths.blast_dir),
        "02_analysis": str(paths.analysis_dir),
        "03_gbif": str(paths.gbif_dir),
        "settings.xlsx": str(paths.settings),
        "log.txt": str(paths.logfile),
    })
else:
    st.info("No project loaded yet.")

st.markdown("➡️ Continue to **📤 Input Files** in the sidebar.")