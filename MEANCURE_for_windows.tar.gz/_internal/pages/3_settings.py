from __future__ import annotations

import streamlit as st

import pipeline
import common

st.set_page_config(page_title="Settings", layout="wide")
common.patch_pipeline_hooks()
paths = common.require_project()
common.init_default_settings()

st.title("⚙️ Pipeline Settings")
st.caption(f"Project: `{paths.root}`")
st.caption("Fields marked with :red[*] are required before that step can be run.")

fasta_files = common.list_files(paths.input, (".fasta", ".fa", ".fna", ".txt"))
xlsx_files = common.list_files(paths.input, (".xlsx",))
csv_files = common.list_files(paths.input, (".csv",))
blast_out_files = common.list_files(paths.blast_results, (".out",))
results_files = common.list_files(paths.analysis_results, (".xlsx",))

bs = dict(st.session_state["blast_settings"])
an = dict(st.session_state["analysis_settings"])
gb = dict(st.session_state["gbif_settings"])
rf = dict(st.session_state["run_flags"])


# =============================================================================
# Info box content for each step
# =============================================================================

BLAST_STEP_INFO = """
**What this step does:** builds a local BLAST nucleotide database from your
reference FASTA (`makeblastdb`), then searches your ESV query sequences
against it (`blastn`), split into chunks for efficient processing.

**Settings on this page:**
- **Reference FASTA file** — the reference database to search against (uploaded
  on the Input Files page).
- **ESV FASTA** — the query sequences to BLAST (uploaded on the Input Files
  page, the output of Apscale). Headers must match the unique ID `hash` column in your ESV table.
- **Maximum target sequences** — maximum number of hits BLAST reports per query
  sequence. Higher values find more candidate matches per ESV but increase
  runtime and output file size. 50 is a reasonable default; raise it if you
  suspect close matches are being missed.

**Output:** `01_blast/results/blast_<timestamp>.out` — raw tabular BLAST
hits, which is then used in the Analysis step.
"""

ANALYSIS_STEP_INFO = """
**What this step does:** filters raw BLAST hits by alignment length and
percent identity, scores remaining candidates (optionally with the help of a
curated scoring file), picks the best taxonomic hit per ESV, and joins the
result back to your ESV abundance table (also keeps a record of other possible candidates).

**Settings on this page:**
- **ESV table** — the Excel table of ESV sequences + per-sample read counts
  (uploaded on the Input Files page, the output of Apscale).
- **Use a scoring file** — optional. If enabled, adds a curated score (e.g.
  regional plausibility) on top of the BLAST-based score. `Score type`
  selects which column of the scoring file to use.
- **Length threshold** — minimum alignment length (in bp) for a BLAST hit to
  be kept. Hits shorter than this are discarded before scoring. Raise this
  to be stricter about partial/fragmentary alignments.
- **Existing blast_\\*.out** — only shown if the BLAST step above is
  disabled; choose a previous BLAST run's output instead of
  re-running BLAST.

**Output:** `02_analysis/results/results_<timestamp>.xlsx` — one row per
ESV with taxonomy, score, and sample read counts. The output is then used by the GBIF step.
"""

GBIF_STEP_INFO = """
**What this step does:** matches the taxonomy assigned to each ESV against
the GBIF backbone, then checks whether that species/genus/family has been
recorded within a chosen geographic search circle (and, optionally, a year
range) — flagging each ESV's taxonomic assignment as `plausible` or
`implausible` based on local occurrence data.

**Settings on this page:**
- **Existing results_\\*.xlsx** — only shown if the Analysis step above is
  disabled; lets you reuse a previous Analysis run's output.
- **Center point & radius** — click the map (or type lon/lat/radius_m
  manually) to define the geographic search area for GBIF occurrence
  queries.
- **Year(s)** — restrict occurrence counts to a year range. Accepts a
  single year (`2000` = from 2000 to present) or full GBIF range syntax
  (`2010,2020`, `*,2020`, `2010,*`).
- **Minimum occurrences** — minimum number of GBIF records required within the
  search circle for a taxon to count as "occurring in the area".
- **Number of points** — how many points are used to approximate the search circle
  as a polygon for the GBIF query (and how many green dots are drawn on
  the map). Higher = smoother circle, but slower query.
- **requests per second / Workers unauthorised / Workers authorised** — control request rate and
  concurrency against the GBIF API. Higher values speed up large runs but
  risk hitting GBIF's rate limits if you're not using credentials (set on
  the Run Pipeline page).

**Output:** `03_gbif/results/gbif_<timestamp>_results_with_gbif_presence.xlsx`
— your results table annotated with GBIF plausibility columns.
"""

# =============================================================================
# Step 1 — BLAST
# =============================================================================
with st.expander("ℹ️ About this step — click to expand"):
    st.markdown(BLAST_STEP_INFO)

st.header("🧬 Step 1 — BLAST")

with st.container(key="run_blast_checkbox"):
    rf["run_blast"] = st.checkbox("Run BLAST step", value=rf["run_blast"])


bs["reference_fasta"] = common.pick_file(
    common.mandatory_label("Reference FASTA"), fasta_files, bs.get("reference_fasta"), key="ref_fasta_sel"
)
if rf["run_blast"]:
    common.show_required_file_marker(paths, bs["reference_fasta"], paths.input)

bs["esv_fasta"] = common.pick_file(
    common.mandatory_label("ESV FASTA"), fasta_files, bs.get("esv_fasta"), key="esv_fasta_sel"
)
if rf["run_blast"]:
    common.show_required_file_marker(paths, bs["esv_fasta"], paths.input)

bs["max_target_seqs"] = st.number_input(
    "Maximum target sequences", min_value=1,
    value=int(bs.get("max_target_seqs") or 50), step=1,
    format="%d",
    help=" Maximum number of hits BLAST reports per query sequence. Higher values find more candidate matches per ESV but increase runtime and output file size. 50 is a reasonable default; raise it if you suspect close matches are being missed.",
)

st.divider()

# =============================================================================
# Step 2 — Analysis
# =============================================================================
with st.expander("ℹ️ About this step — click to expand"):
    st.markdown(ANALYSIS_STEP_INFO)

st.header("📈 Step 2 — Analysis")
with st.container(key="run_analysis_checkbox"):
    rf["run_analysis"] = st.checkbox("Run Analysis step", value=rf["run_analysis"])

an["esv_table"] = common.pick_file(
    common.mandatory_label("ESV table (.xlsx)"), xlsx_files, an.get("esv_table"), key="esv_table_sel"
)
if rf["run_analysis"]:
    common.show_required_file_marker(paths, an["esv_table"], paths.input)

    use_score = st.checkbox("Use a scoring file (to incorporate quality information from the reference sequences or local occurrence information)", value=bool(common.as_text(an.get("score_file"))))

    an["score_type"] = st.text_input(
        "Score type", value=common.as_text(an.get("score_type")) or "all",
        help="'all' → uses 'Score' column; 'local' → uses 'score_local'; or type an exact column name (e.g. 'Score_ger').",
    )
else:
    an["score_file"] = ""
    an["score_type"] = ""

an["length_threshold"] = st.number_input(
    "Length threshold", min_value=1,
    value=int(an.get("length_threshold") or 200), step=10,
    format="%d",
    help="Minimum alignment length (in bp) for a BLAST hit to be kept. Hits shorter than this are discarded before scoring. Raise this to be stricter about partial/fragmentary alignments."
)

an["blast_results"] = ""
if not rf["run_blast"]:
    st.caption("BLAST step is disabled — pick an existing BLAST output to use instead:")
    sel = st.selectbox(common.mandatory_label("Existing blast_*.out"), ["<none>"] + blast_out_files)
    if sel != "<none>":
        an["blast_results"] = common.rel_to_root(paths, paths.blast_results / sel)
    if rf["run_analysis"]:
        common.show_required_file_marker(paths, an["blast_results"], paths.input)

st.divider()

# =============================================================================
# Step 3 — GBIF
# =============================================================================
with st.expander("ℹ️ About this step — click to expand"):
    st.markdown(GBIF_STEP_INFO)

st.header("🗺️ Step 3 — GBIF")

with st.container(key="run_gbif_checkbox"):
    rf["run_gbif"] = st.checkbox("Run GBIF step", value=rf["run_gbif"])

gb["input_results_xlsx"] = ""
if not rf["run_analysis"]:
    st.caption("Analysis step is disabled — pick an existing results_*.xlsx to use instead:")
    sel2 = st.selectbox(common.mandatory_label("Existing results_*.xlsx"), ["<none>"] + results_files)
    if sel2 != "<none>":
        gb["input_results_xlsx"] = common.rel_to_root(paths, paths.analysis_results / sel2)
    if rf["run_gbif"]:
        common.show_required_file_marker(paths, gb["input_results_xlsx"], paths.input)

st.session_state.setdefault("gbif_year_from", common.as_text(gb.get("year_from")))
st.session_state.setdefault("gbif_lon", common.as_text(gb.get("lon")))
st.session_state.setdefault("gbif_lat", common.as_text(gb.get("lat")))
st.session_state.setdefault("gbif_radius_m", common.as_text(gb.get("radius_m")))

st.markdown("**Click on the map to set the center point**")

try:
    _preview_lat = float(common.normalize_decimal_input(st.session_state["gbif_lat"]))
    _preview_lon = float(common.normalize_decimal_input(st.session_state["gbif_lon"]))
except (TypeError, ValueError):
    _preview_lat = _preview_lon = None

try:
    _radius_norm = common.normalize_decimal_input(st.session_state["gbif_radius_m"])
    _preview_radius = float(_radius_norm) if _radius_norm else 1000.0
except (TypeError, ValueError):
    _preview_radius = 1000.0

_preview_npts = int(gb.get("n_points") or 12)

clicked = common.render_gbif_click_map(
    _preview_lat, _preview_lon, _preview_radius, _preview_npts
)

if clicked is not None:
    clicked_lat, clicked_lon = clicked
    st.session_state["gbif_lat"] = f"{clicked_lat:.6f}"
    st.session_state["gbif_lon"] = f"{clicked_lon:.6f}"
    st.rerun()

st.caption("📌 Current center · 🟢 Circle boundary points (n_points) · Click anywhere to move the center.")

cA, cB = st.columns(2)

with cA:
    st.text_input(
        common.mandatory_label("Years(s)"), key="gbif_year_from",
        help=(
            "Count occurrences from this year onwards (inclusive). e.g. 2000\n\n"
            "You can also use the full GBIF API range syntax:\n"
            "- `2010` → from 2010 to present\n"
            "- `2010,2020` → only between 2010 and 2020 (inclusive)\n"
            "- `*,2020` → up to and including 2020"
        ),
    )
    if rf["run_gbif"]:
        common.show_required_marker(st.session_state["gbif_year_from"])
        try:
            resolved_year = pipeline.build_gbif_year_param(st.session_state["gbif_year_from"])
            st.caption(f"→ GBIF query will use: `year={resolved_year}`")
        except ValueError:
            pass  # empty — already flagged by the required marker above

    st.text_input(
        common.mandatory_label("Longitude (lon)"), key="gbif_lon",
        help="WGS84 decimal degrees, e.g. 8.6821 — or click the map above. "
             "A comma decimal separator (8,6821) is auto-converted.",
    )
    if rf["run_gbif"]:
        common.show_required_marker(st.session_state["gbif_lon"])

    st.text_input(
        common.mandatory_label("Latitude (lat)"), key="gbif_lat",
        help="WGS84 decimal degrees, e.g. 50.1109 — or click the map above. "
             "A comma decimal separator (50,1109) is auto-converted.",
    )
    if rf["run_gbif"]:
        common.show_required_marker(st.session_state["gbif_lat"])

    st.text_input(
        common.mandatory_label("Radius in meters"), key="gbif_radius_m",
        help="Search circle radius in meters, e.g. 5000",
    )
    if rf["run_gbif"]:
        common.show_required_marker(st.session_state["gbif_radius_m"])

    gb["year_from"] = st.session_state["gbif_year_from"]
    gb["lon"] = common.normalize_decimal_input(st.session_state["gbif_lon"])
    gb["lat"] = common.normalize_decimal_input(st.session_state["gbif_lat"])
    gb["radius_m"] = common.normalize_decimal_input(st.session_state["gbif_radius_m"])

with cB:
    gb["min_occurrences"] = st.number_input(
        "Minimum occurences", min_value=1,
        value=int(gb.get("min_occurrences") or 5), step=1,
        format="%d",
        help="Minimum number of GBIF records required within the search circle for a taxon to count as 'occurring in the area'.",
    )
    gb["n_points"] = st.number_input(
        "Number of points (circle polygon)", min_value=4,
        value=int(gb.get("n_points") or 12), step=1,
        format="%d",
        help="How many points are used to approximate the search circle as a polygon for the GBIF query (and how many green dots are drawn on the map). Higher = smoother circle, but slower query."
    )
    gb["rps"] = st.number_input(
        "Requests per second", min_value=0.5,
        value=float(gb.get("rps") or 4.0), step=0.5,
        format="%.1f",
        help="Controls request rate and concurrency against the GBIF API. Higher values speed up large runs but risk hitting GBIF's rate limits. Higher rate possible with GBIF credentials."
    )

st.markdown("**Concurrency**")
cC, cD = st.columns(2)
with cC:
    gb["workers_unauth"] = st.number_input(
        "Workers unauthorised", min_value=1,
        value=int(gb.get("workers_unauth") or 4), step=1,
        format="%d",
        help="Simultaneous searches in GBIF (without credentials). Rate limits apply similar to the requests per second."
    )
with cD:
    gb["workers_auth"] = st.number_input(
        "Workers authorised", min_value=1,
        value=int(gb.get("workers_auth") or 8), step=1,
        format="%d",
        help="Simultaneous searches in GBIF (with credentials). Rate limits apply similar to the requests per second. More workers possible with credentials."
    )

st.caption(
    "🔑 GBIF credentials are entered on the **Run Pipeline** page right "
    "before starting a run — they are not stored in settings.xlsx."
)

# -----------------------------------------------------------------------
# Persist back to session state
# -----------------------------------------------------------------------
st.session_state["blast_settings"] = bs
st.session_state["analysis_settings"] = an
st.session_state["gbif_settings"] = gb
st.session_state["run_flags"] = rf

st.divider()

missing = common.validate_settings(paths, bs, an, gb, rf)
if missing:
    st.error(
        "⚠️ The following required settings are still missing:\n\n"
        + common.format_missing_settings(missing)
    )
else:
    st.success("✅ All required settings for the enabled steps are filled in.")

if st.button("💾 Save settings.xlsx", type="primary"):
    common.save_settings_to_disk(paths)
    st.success(f"Saved {paths.settings}")

st.markdown("➡️ Continue to **▶ Run Pipeline** in the sidebar.")