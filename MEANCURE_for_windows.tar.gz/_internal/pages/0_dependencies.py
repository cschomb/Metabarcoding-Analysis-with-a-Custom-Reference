from __future__ import annotations

import pandas as pd
import streamlit as st
import dependency_manager as dm

st.title("🔧 Dependencies")
st.caption(
    "This pipeline needs several Python packages and the BLAST+ command-line "
    "tools (`makeblastdb`, `blastn`). Python packages can be auto-installed "
    "below. BLAST+ must be installed manually — see instructions below."
)

st.session_state.setdefault("dep_log", [])


def _log(msg):
    if msg:
        st.session_state["dep_log"].append(str(msg))


def render_status_table(statuses: list[dm.DepStatus]):
    df = pd.DataFrame([s._asdict() for s in statuses])
    df["found"] = df["found"].map(lambda b: "✅" if b else "❌")
    st.dataframe(df, use_container_width=True, hide_index=True)


st.subheader("Python packages")
py_status = dm.check_all_python_packages()
render_status_table(py_status)
missing_py = [s.name for s in py_status if not s.found]

c1, c2 = st.columns(2)
if c1.button("🔄 Re-check"):
    st.rerun()

if c2.button("📦 Install missing packages", disabled=not missing_py):
    with st.spinner("Installing Python packages..."):
        ok = dm.install_python_packages(missing_py, _log)
    (st.success if ok else st.error)(
        "Done — click Re-check." if ok else "Install failed — see log below."
    )

if st.session_state["dep_log"]:
    with st.expander("Installation log", expanded=True):
        st.code("\n".join(st.session_state["dep_log"]), language="text")

st.divider()

st.subheader("BLAST+ binaries")
bin_status = dm.check_all_binaries()
render_status_table(bin_status)
missing_bin = [s.name for s in bin_status if not s.found]

if missing_bin:
    st.warning("⚠️ BLAST+ is not fully installed. Follow the instructions below, then click Re-check.")
    st.code(dm.get_blast_install_instructions(), language="text")
else:
    st.success("✅ BLAST+ found.")

if st.button("🔄 Re-check BLAST+"):
    st.rerun()