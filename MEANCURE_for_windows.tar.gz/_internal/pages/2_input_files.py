from __future__ import annotations

import pandas as pd
import streamlit as st

import pipeline as pl
import common

st.set_page_config(page_title="Input Files", layout="wide")
common.patch_pipeline_hooks()
paths = common.require_project()
common.init_default_settings()

st.title("📤 Input Files")
st.caption(
    "Upload each file below. It is saved into this project's `input/` folder "
    "and immediately linked to the matching parameter on the Settings page"
)


def _file_upload_box(title: str, sheet: str, parameter: str, filetypes: list[str], info_md: str, optional: bool = False):
    current_dict = st.session_state[common.SETTINGS_SESSION_KEYS[sheet]]
    current_value = common.as_text(current_dict.get(parameter))

    st.subheader(title + (" (optional)" if optional else ""))

    with st.expander("ℹ️ Format requirements — click to expand"):
        st.markdown(info_md)

    if current_value:
        exists = (paths.input / current_value).exists()
        icon = "✅" if exists else "⚠️"
        msg = f"{icon} Currently set: `{current_value}`"
        if not exists:
            msg += " — file missing in input/!"
        st.write(msg)
    else:
        st.write("— Not set yet —")

    uploader_key = f"uploader_{parameter}"
    processed_key = f"processed_{parameter}"

    uploaded = st.file_uploader(
        f"Drag & drop a file here, or browse ({', '.join(filetypes)})",
        type=filetypes,
        key=uploader_key,
    )

    if uploaded is not None:
        fingerprint = f"{uploaded.name}:{uploaded.size}"

        if st.session_state.get(processed_key) != fingerprint:
            dest = paths.input / uploaded.name
            total = uploaded.size or 1
            chunk_size = 8 * 1024 * 1024

            progress = st.progress(0, text=f"Saving {uploaded.name} (0 MB / {total / 1e6:.1f} MB)")
            written = 0
            last_pct_shown = -1

            with open(dest, "wb") as f:
                while True:
                    chunk = uploaded.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    written += len(chunk)
                    pct = int(written * 100 / total)
                    if pct != last_pct_shown:
                        progress.progress(
                            min(written / total, 1.0),
                            text=f"Saving {uploaded.name} ({written / 1e6:.1f} MB / {total / 1e6:.1f} MB)",
                        )
                        last_pct_shown = pct

            progress.empty()

            common.set_setting_value(paths, sheet, parameter, uploaded.name)
            st.session_state[processed_key] = fingerprint
            st.success(f"Saved `{uploaded.name}` → linked to `{parameter}`.")
            st.rerun()

    if optional and current_value:
        if st.button(f"🗑️ Clear {parameter}", key=f"clear_{parameter}"):
            common.set_setting_value(paths, sheet, parameter, "")
            st.session_state.pop(processed_key, None)
            st.rerun()

    st.divider()


# =============================================================================
# Format descriptions for each input file
# =============================================================================

REFERENCE_FASTA_INFO = """
**A nucleotide reference databse in FASTA format**, used to build the local BLAST database ('makeblastdb -dbtype nucl').

- The headers of the sequences must be of the format '>[accession number];tax=p:[phylum],c:[class],o:[order],f[family],g:[genus],s:[species]'
- Optionally, they can contain further information on taxon IDs at the end.
- Example: '>AF046950.1;tax=p:Tracheophyta,c:Magnoliopsida,o:Asterales,f:Asteraceae,g:Bellis,s:Bellis_perennis,ncbitax:41492,gbiftax:3117424,coltax:5WH44'.

"""

ESV_SEQUENCES_INFO = """
**A FASTA file** containing the ESV sequences to be analysed.

- The FASTA headers must be the unique identifiers (hashs) of the ESVs from the ESV table.

"""

ESV_TABLE_INFO = """
**A .XLSX table** containing colums with unique identifiers (hashs), the nucleotide sequence, and read counts for each sample for every ESV.

- The ESV table output from Apscale.
- Example:

| hash                                    | sequence                                     | sample_1 | ... | sample_n |
|-----------------------------------------|----------------------------------------------|----------|-----|----------|
| d03850702e6fe2433d53fadddfce4f378add... | TTAAACTCAGCGGGTAGTCCCGCCTGACCTGGGGTCACATT... | 216      | 70  | 400      |
| 7ddcf83c8cfa7ed3a6c703a1b4b06cb77fa0... | TTAAACTCAGCGGGTAGTCCCGCCTGACCTGGGGTCACAAT... | 503      | 211 | 734      |
| ...                                     | ...                                          | ...      | ... | ...      |



"""

SCORING_FILE_INFO = """
**A .CSV or .XLSX file containing quality information about the reference sequences**, which can be incorporated into the analysis.

- Must at least contain a column with the accession numbers from the reference database and named score column (which can be chosen via score type in the settings of this app).
- Other columns are optional (taxonomy columns, other scoring methods,  quality indicator, etc.).
- Example:

| Accession | Phylum | Class | Order | Family | Genus | Species | coltax | gbiftax | ncbitax | category | Score | occurence_score | local_score | quality |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| AF046950.1 | Tracheophyta | Magnoliopsida | Asterales | Asteraceae | Bellis | Bellis_perennis | 41492 | 3117424 | 5WH44 | accepted | 4 | 5 | 9 | gold |
| AF069464.2 | Tracheophyta | Magnoliopsida | Lamiales | Plantaginaceae | Veronica | Veronica_annulata | 86152 | 7923758 | B443S | low_coverage | 2 | 0 | 2 | silver |
| ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... |

- During analysis, scores are incorporated into the analysis to chose the most likely reference sequence. In the example the scoring values are tuned to the rest of the analysis, so that in case of similar BLAST scores, the sequence with the higher quality is chosen.


"""

_file_upload_box("Reference FASTA", "blast", "reference_fasta", filetypes=["fasta", "fa", "fas", "fna"], info_md=REFERENCE_FASTA_INFO,)
_file_upload_box("ESV sequences (query FASTA)", "blast", "esv_fasta", filetypes=["fasta", "fa", "fas", "fna"], info_md=ESV_SEQUENCES_INFO)
_file_upload_box("ESV table", "analysis", "esv_table", filetypes=["xlsx"], info_md=ESV_TABLE_INFO)
_file_upload_box("Scoring file", "analysis", "score_file", filetypes=["csv", "xlsx"], info_md=SCORING_FILE_INFO, optional=True)

st.subheader("All files currently in input/")
files = sorted(paths.input.glob("*"))
if files:
    st.dataframe(
        pd.DataFrame({
            "file": [f.name for f in files],
            "size (KB)": [round(f.stat().st_size / 1024, 1) for f in files],
        }),
        use_container_width=True, hide_index=True,
    )
    to_delete = st.selectbox("Delete a file", ["(none)"] + [f.name for f in files])
    if to_delete != "(none)" and st.button(f"🗑️ Delete {to_delete}"):
        (paths.input / to_delete).unlink(missing_ok=True)
        st.rerun()
else:
    st.write("No files yet.")

st.divider()

missing_files = common.validate_input_files(
    paths,
    st.session_state["blast_settings"],
    st.session_state["analysis_settings"],
    st.session_state["gbif_settings"],
    st.session_state["run_flags"],
)

if missing_files:
    st.error(
        "⚠️ The following required input files are still missing:\n\n"
        + common.format_missing_settings(missing_files)
    )
else:
    st.success("✅ All required input files for the enabled steps are set.")

st.markdown("➡️ Continue to **⚙️ Settings** in the sidebar.")