from __future__ import annotations

import os

import streamlit as st

import pipeline
import common

st.set_page_config(page_title="Run Pipeline", layout="wide")
common.patch_pipeline_hooks()
paths = common.require_project()
common.init_default_settings()

st.title("▶ Run Pipeline")

rf = st.session_state["run_flags"]
bs = st.session_state["blast_settings"]
an = st.session_state["analysis_settings"]
gb = st.session_state["gbif_settings"]

active_steps = [s for s in ("blast", "analysis", "gbif") if rf.get(f"run_{s}")]
missing = common.validate_settings(paths, bs, an, gb, rf)
missing_files = common.validate_input_files(paths, bs, an, gb, rf)

c1, c2, c3 = st.columns(3)
for col, step in zip((c1, c2, c3), ("blast", "analysis", "gbif")):
    label = common.STAGE_LABELS.get(step, step.capitalize())
    col.metric(label, "✅ ON" if rf.get(f"run_{step}") else "⛔ OFF")
st.caption("Steps are selected on the Settings page.")

if missing_files:
    st.error(
        "📤 Missing input files:\n\n"
        + common.format_missing_settings(missing_files)
        + "\n\n➡️ Go to **Input Files** to upload these."
    )

if missing:
    st.error(
        "❌ Cannot start — required settings are missing:\n\n"
        + common.format_missing_settings(missing)
        + "\n\n➡️ Go to **Settings** to fill these in."
    )

with st.expander("🔑 GBIF credentials (optional — enables higher concurrency & rate limits)"):
    gbif_user = st.text_input("GBIF username", value="", key="run_gbif_user")
    gbif_pwd = st.text_input("GBIF password", value="", type="password", key="run_gbif_pwd")
    st.caption(
        "Leave both blank to query anonymously (lower concurrency, stricter "
        "rate limits). Credentials are only used for this run and are not saved."
    )

running = common.is_running("pipeline")
start_disabled = running or not active_steps or bool(missing)

col_start, col_abort = st.columns(2)

with col_start:
    if st.button("▶ Start pipeline", type="primary", disabled=start_disabled, use_container_width=True):
        common.save_settings_to_disk(paths)

        if gbif_user:
            os.environ["GBIF_USER"] = gbif_user
        if gbif_pwd:
            os.environ["GBIF_PWD"] = gbif_pwd

        steps_str = "all" if len(active_steps) == 3 else ",".join(active_steps)
        common.start_step(
            "pipeline", pipeline.cmd_run, str(paths.root), steps_str,
            abort_check=lambda: common.is_abort_requested("pipeline"),
        )
        st.rerun()

with col_abort:
    with st.container(key="abort_btn_container"):
        if st.button("⏹ Abort pipeline", disabled=not running, use_container_width=True):
            common.request_abort("pipeline")
            st.rerun()

if not active_steps:
    st.info("No steps selected — enable at least one on the Settings page.")

if common.has_run("pipeline"):
    common.render_live_log(paths, "pipeline", active_steps)

st.divider()
st.caption("➡️ Once finished, browse and preview output files on the **Results & Logs** page.")