from __future__ import annotations

import streamlit as st
import common

common.init_session_state()
st.title("📈 Results & Logs")
paths = common.require_paths()

if paths.logfile.exists():
    with st.expander("📜 Full log"):
        st.code(paths.logfile.read_text(encoding="utf-8"), language="text")
    st.download_button("Download log.txt", paths.logfile.read_bytes(), file_name="log.txt")

st.divider()
st.subheader("📂 All output files")

tab_blast, tab_analysis, tab_gbif = st.tabs(["🧬 BLAST", "📊 Analysis", "🌍 GBIF"])

with tab_blast:
    st.caption("Raw BLAST output")
    common.render_file_list(paths.blast_results, "blast_*.out", preview=False)

with tab_analysis:
    st.caption("Final results tables")
    common.render_file_list(paths.analysis_results, "results_*.xlsx", preview=True)
    st.caption("Best BLAST hits")
    common.render_file_list(paths.analysis_results, "best_blast_hits_*.xlsx", preview=True)
    st.caption("Filtered BLAST CSV")
    common.render_file_list(paths.analysis_results, "filtered_blast_results_*.csv", preview=True)

with tab_gbif:
    st.caption("Taxonomy tables, GBIF-annotated results, occurrence cache")
    common.render_file_list(paths.gbif_results, "gbif_*", preview=True)