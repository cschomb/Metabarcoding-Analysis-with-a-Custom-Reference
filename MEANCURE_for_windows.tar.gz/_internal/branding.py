from __future__ import annotations

from pathlib import Path

import streamlit as st

ASSETS_DIR = Path(__file__).parent / "assets"


def _inject_sidebar_css() -> None:
    st.markdown(
        """
        <style>
        [data-testid="stSidebar"] [data-testid="stImage"] {
            display: flex;
            justify-content: center;
            margin-bottom: 0.75rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

def _inject_abort_button_css() -> None:
    st.markdown(
        """
        <style>
        .st-key-abort_btn_container button {
            background-color: #d32f2f !important;
            color: white !important;
            border-color: #d32f2f !important;
        }
        .st-key-abort_btn_container button:hover {
            background-color: #b71c1c !important;
            border-color: #b71c1c !important;
        }
        .st-key-abort_btn_container button:disabled {
            background-color: #e0e0e0 !important;
            color: #9e9e9e !important;
            border-color: #e0e0e0 !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_sidebar_logos(width: int = 160) -> None:
    """
    Displays two logos stacked, centered, at the top of the sidebar.
    Call this BEFORE st.navigation(pages) is constructed so the logos
    appear above the nav menu.
    """
    logo_top = ASSETS_DIR / "logo_top.png"
    logo_bottom = ASSETS_DIR / "logo_bottom.png"

    if not logo_top.exists() and not logo_bottom.exists():
        return

    _inject_sidebar_css()

    with st.sidebar:
        if logo_top.exists():
            st.image(str(logo_top), width=width)
        if logo_bottom.exists():
            st.image(str(logo_bottom), width=width)
        st.divider()


def render_banner() -> None:
    """
    Renders the top-of-page banner in the main content area.
    """
    banner_path = ASSETS_DIR / "banner.png"

    if banner_path.exists():
        st.image(str(banner_path), use_container_width=True)
    else:
        st.markdown(
            """
            <div style="
                background: linear-gradient(90deg, #33691B 0%, #61C634 100%);
                padding: 1.2rem 1.5rem;
                border-radius: 8px;
                margin-bottom: 1rem;
            ">
                <h1 style="color: white; margin: 0; font-size: 1.8rem;">
                    🧬 Metabarcoding Pipeline
                </h1>
                <p style="color: #e6f4d9; margin: 0.2rem 0 0 0; font-size: 0.95rem;">
                    BLAST → Analysis → GBIF occurrence check
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

def _inject_hide_deploy_button_css() -> None:
    st.markdown(
        """
        <style>
        [data-testid="stAppDeployButton"] { display: none !important; }
        </style>
        """,
        unsafe_allow_html=True,
    )

def _inject_metric_text_size_css() -> None:
    st.markdown(
        """
        <style>
        div[data-testid="stMetric"] [data-testid="stMetricLabel"] * {
            font-size: 2rem !important;
        }
        div[data-testid="stMetric"] [data-testid="stMetricValue"] * {
            font-size: 2rem !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

def _inject_run_step_checkbox_css() -> None:
    st.markdown(
        """
        <style>
        .st-key-run_blast_checkbox div[data-testid="stCheckbox"],
        .st-key-run_analysis_checkbox div[data-testid="stCheckbox"],
        .st-key-run_gbif_checkbox div[data-testid="stCheckbox"] {
            transform: scale(1.4);
            transform-origin: left center;
            margin: 0.4rem 0;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

def render_branding() -> None:
    _inject_run_step_checkbox_css()
    _inject_metric_text_size_css()
    _inject_hide_deploy_button_css()
    _inject_abort_button_css()
    render_sidebar_logos()
    render_banner()
    