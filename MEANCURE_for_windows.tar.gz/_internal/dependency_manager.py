from __future__ import annotations

import importlib
import importlib.util
import platform
import shutil
import subprocess
import sys
from typing import NamedTuple, Callable
import winproc

# ---------------------------------------------------------------------------
# Required Python packages: pip name -> import name
# ---------------------------------------------------------------------------
PY_PACKAGES = {
    "pandas": "pandas",
    "numpy": "numpy",
    "requests": "requests",
    "openpyxl": "openpyxl",
    "pyproj": "pyproj",
    "tqdm": "tqdm",
    "urllib3": "urllib3",
    "folium": "folium",
    "streamlit-folium": "streamlit_folium",
}

BLAST_BINARIES = ["makeblastdb", "blastn"]
NCBI_BLAST_VERSION = "2.16.0"
NCBI_DOWNLOAD_PAGE = (
    f"https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/{NCBI_BLAST_VERSION}/"
)


class DepStatus(NamedTuple):
    name: str
    kind: str       # "python" | "binary"
    found: bool
    detail: str


# ---------------------------------------------------------------------------
# Python package checks
# ---------------------------------------------------------------------------

def find_missing_python_packages() -> list[str]:
    if getattr(sys, "frozen", False):
        return []  # Bundled by PyInstaller — nothing to check or install.
    missing = []
    for pip_name, import_name in PY_PACKAGES.items():
        if importlib.util.find_spec(import_name) is None:
            missing.append(pip_name)
    return missing


def check_python_package(pip_name: str, import_name: str) -> DepStatus:
    try:
        mod = importlib.import_module(import_name)
        version = getattr(mod, "__version__", "unknown")
        return DepStatus(pip_name, "python", True, f"version {version}")
    except ImportError:
        return DepStatus(pip_name, "python", False, "not installed")


def check_all_python_packages() -> list[DepStatus]:
    return [check_python_package(p, i) for p, i in PY_PACKAGES.items()]


def install_python_packages(missing_pip_names: list[str], log) -> bool:
    if getattr(sys, "frozen", False):
        log("Running as a bundled executable — all packages are already included.")
        return True
    if not missing_pip_names:
        return True

    def _run(cmd: list[str]) -> subprocess.CompletedProcess:
        log(f"Running: {' '.join(cmd)}")
        return subprocess.run(cmd, capture_output=True, text=True, **winproc.no_window_kwargs())

    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", *missing_pip_names]
    proc = _run(cmd)
    log(proc.stdout)
    if proc.returncode == 0:
        return True

    log(proc.stderr)
    log("Normal install failed — retrying with --user ...")

    cmd_user = [sys.executable, "-m", "pip", "install", "--user", "--upgrade", *missing_pip_names]
    proc_user = _run(cmd_user)
    log(proc_user.stdout)
    if proc_user.returncode == 0:
        return True

    log(proc_user.stderr)
    return False


# ---------------------------------------------------------------------------
# BLAST+ — check only, no auto-install
# ---------------------------------------------------------------------------

def check_binary(name: str) -> DepStatus:
    path = shutil.which(name)
    if not path:
        return DepStatus(name, "binary", False, "not found on PATH")
    try:
        out = subprocess.run([path, "-version"], capture_output=True, text=True, timeout=10, **winproc.no_window_kwargs())
        text = (out.stdout or out.stderr).strip()
        detail = text.splitlines()[0] if text else path
    except Exception:
        detail = path
    return DepStatus(name, "binary", True, detail)


def check_all_binaries() -> list[DepStatus]:
    return [check_binary(n) for n in BLAST_BINARIES]


def get_blast_install_instructions() -> str:
    """
    Returns a platform-aware, human-readable message explaining how to
    install BLAST+ manually. No binaries are bundled with the app —
    users install BLAST+ themselves and it must be discoverable on PATH.
    """
    system = platform.system()
    win_installer = f"ncbi-blast-{NCBI_BLAST_VERSION}+-x64-win64.exe"
    win_url = f"{NCBI_DOWNLOAD_PAGE}{win_installer}"

    lines = [
        "BLAST+ (makeblastdb, blastn) was not found on your PATH.",
        "",
    ]

    if system == "Windows":
        lines += [
            "➡️  Download the Windows installer from the official NCBI FTP server:",
            "",
            f"   https://ftp.ncbi.nlm.nih.gov/blast/executables/LATEST/",
            "",
            f"(Full folder listing, if the version above has changed: {NCBI_DOWNLOAD_PAGE})",
            "",
            "During installation:",
            "",
            "  ⚠️  IMPORTANT: Make sure the checkbox",
            "      'Add BLAST+ bin directory to the PATH environment variable'",
            "      is CHECKED before clicking Install.",
            "      If you miss this, Windows (and this app) will not be able",
            "      to find blastn / makeblastdb afterwards.",
            "",
            "After installing:",
            "  1) Fully close MEANCURE (including this window).",
            "  2) Start MEANCURE again — Windows only applies PATH changes",
            "     to newly started programs, not ones already running.",
            "  3) Open the Dependencies page and click 'Re-check'.",
            "",
            "If it's still not found after restarting, open a new Command Prompt",
            "and check manually:",
            "       blastn -version",
            "       makeblastdb -version",
            "If those also fail there, the PATH entry wasn't added — rerun the",
            "installer and make sure the checkbox above is checked, or add the",
            "BLAST 'bin' folder to PATH manually via",
            "  Windows Settings → System → About → Advanced system settings →",
            "  Environment Variables.",
            "",
        ]
    elif system == "Linux":
        lines += [
            "Recommended installation options:",
            "",
            "  1) Via conda / mamba:",
            "       conda install -c bioconda blast",
            "",
            "  2) Via your Linux package manager:",
            "       sudo apt-get install ncbi-blast+      # Debian/Ubuntu",
            "       sudo dnf install ncbi-blast+           # Fedora",
            "       sudo pacman -S blast+                  # Arch",
            "",
            "  3) Manual download (precompiled binaries):",
            f"       {NCBI_DOWNLOAD_PAGE}",
            "",
        ]
    elif system == "Darwin":
        lines += [
            "Recommended installation options:",
            "",
            "  1) Via Homebrew:",
            "       brew install blast",
            "",
            "  2) Via conda / mamba:",
            "       conda install -c bioconda blast",
            "",
            "  3) Manual download (precompiled binaries):",
            f"       {NCBI_DOWNLOAD_PAGE}",
            "",
        ]
    else:
        lines += [
            "Manual download (precompiled binaries, all platforms):",
            f"       {NCBI_DOWNLOAD_PAGE}",
            "",
        ]

    lines += [
        "Verify afterwards with:",
        "       blastn -version",
        "       makeblastdb -version",
        "",
        "Then reload this page / click 'Re-check' to confirm detection.",
    ]
    return "\n".join(lines)