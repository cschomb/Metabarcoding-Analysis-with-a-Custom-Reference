"""
Helper for suppressing console windows when spawning subprocesses from a
GUI context on Windows (the app is launched via pythonw.exe/pyw.exe, which
has no console of its own — but console-subsystem child processes like
blastn.exe, makeblastdb.exe, pip, and powershell.exe still pop up their
own window unless explicitly told not to).
"""
from __future__ import annotations

import subprocess
import sys


def no_window_kwargs() -> dict:
    """
    Extra kwargs to merge into subprocess.run()/Popen() calls so spawned
    console applications (blastn.exe, makeblastdb.exe, pip, powershell.exe)
    never flash a visible window — including the stdin redirect, which
    matters because the parent process (pythonw.exe) has no console of
    its own to inherit a valid input handle from. Without this, Windows
    can still briefly allocate a console for the child even with
    CREATE_NO_WINDOW set, especially under rapid repeated subprocess calls
    (e.g. one blastn.exe invocation per FASTA chunk).
    No-op on non-Windows platforms.
    """
    if sys.platform != "win32":
        return {}

    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE

    return {
        "creationflags": subprocess.CREATE_NO_WINDOW,
        "startupinfo": si,
        "stdin": subprocess.DEVNULL,
    }