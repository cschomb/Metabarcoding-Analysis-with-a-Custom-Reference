HOW TO RUN
   ON WINDOWS
    1. Extract this entire folder somewhere on your computer.
    2. Double-click MEANCURE.vbs.
       Windows may show a small "Open File - Security Warning" dialog
       the first time (this is standard for any downloaded script, not
       a virus warning) — click "Run".
       or
       start the application via command line from the menacure.py script
    3. A small "MEANCURE" window will appear, and your browser will
       open automatically after a couple of seconds.
    4. To quit, close the "MEANCURE" window.

   ON LINUX
   1. Extract this entire folder somewhere on your computer.
    2. Start the application via command line from the menacure.py script
    3. A small "MEANCURE" window will appear, and your browser will
       open automatically after a couple of seconds (when running WSL, the browser does not open automatically. Just copy the IP adress into a browser window).